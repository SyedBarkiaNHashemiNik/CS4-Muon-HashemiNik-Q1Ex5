import java.util.*;

public class Store {
  private String name;
  private double earnings;
  private ArrayList<Item> itemList;
  private static ArrayList<Store> storeList = new ArrayList<>();

  public Store(String name){
    // Initialize name to parameter and earnings to zero
    // Initialize itemList as a new ArrayList
    // add 'this' store to storeList
    earnings = 0;
    this.name = name;
    itemList = new ArrayList<>();
    storeList.add(this);
  }

  public String getName(){
    return name;
  }
  public double getEarnings(){
    return earnings;
  }
  public void sellItem(int index){
    // check if index is within the size of the itemList (if not, print statement that there are only x items in the store)
    // get Item at index from itemList and add its cost to earnings
    // print statement indicating the sale

    if (index < itemList.size()) {
      itemList.get(index);
      earnings += itemList.get(index).getCost();
      System.out.println(itemList.get(index).getName() + " has successfully been sold.");
    }
    else {
      System.out.println("there are only " + itemList.size() + " items in this store");
    }
  }
  public void sellItem(String name){
    // check if Item with given name is in the itemList (you will need to loop over itemList) (if not, print statement that the store doesn't sell it)
    // get Item from itemList and add its cost to earnings
    // print statement indicating the sale
    for (int x = 0; x < itemList.size(); x++) {
      if (name.equals(itemList.get(x).getName())) {
        itemList.get(x);
        earnings += itemList.get(x).getCost();
        System.out.println(name + " has been successfully sold");
        break;
      }
      if (x == itemList.size()-1) {
        System.out.println("This store does not sell " + name);
      }
    }
  }
  public void sellItem(Item i){
    // check if Item i exists in the store (there is a method that can help with this) (if not, print statement that the store doesn't sell it)
    // get Item i from itemList and add its cost to earnings
    // print statement indicating the sale
    for (int x = 0; x < itemList.size(); x++) {
      if (itemList.get(x) == i) {
        earnings += i.getCost();
        System.out.println(i.getName() + " was successfully sold");
        break;
      }
      if (x == itemList.size()-1) {
        System.out.println("This store does not sell " + i.getName());
      }        
    }
  }
  public void addItem(Item i){
    // add Item i to store's itemList
    itemList.add(i);
  }
  public void filterType(String type){
    // loop over itemList and print all items with the specified type
    System.out.println("All items of " + type + " type");
    for (int x = 0; x < itemList.size(); x++) {
      if (type.equals(itemList.get(x).getType())) {
        System.out.println(itemList.get(x).getName());
      }
    }
  }
  public void filterCheap(double maxCost){
    // loop over itemList and print all items with a cost lower than or equal to the specified value
    System.out.println("All items that are worth " + maxCost + " dollars or less");
    for (int x = 0; x < itemList.size(); x++) {
      if (itemList.get(x).getCost() <= maxCost) {
        System.out.println(itemList.get(x).getName());
      }
    }
  }
  public void filterExpensive(double minCost){
    // loop over itemList and print all items with a cost higher than or equal to the specified value
    System.out.println("All items that are worth " + minCost + " dollars or more");
    for (int x = 0; x < itemList.size(); x++) {
      if (itemList.get(x).getCost() >= minCost) {
        System.out.println(itemList.get(x).getName());
      }
    }
  }
  public static void printStats(){
    // loop over storeList and print the name and the earnings'Store.java'
    for (int x = 0; x < storeList.size(); x++) {
      System.out.println("name: " + storeList.get(x).getName() + "\n" + "earnings: " + storeList.get(x).getEarnings());
    }
  }
}
